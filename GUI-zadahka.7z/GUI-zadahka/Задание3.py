#!/usr/bin/env python
# coding: utf-8

# # Сессия_1

# *В этой сессии необходимо изучить и предобработать представленную выборку.Для этого пoтребуется выполнить следующие пункты:*
# ***
# * *Разведочный анализ данных*
# * *Обработка попущенных значений*
# * *Разделение сложных атрибутов*
# * *Формирование словаря*
# * *Кодирование номинативных признаков*
# ***
# *После этой сессии выборка будет обработана и изучена, что позволит перейти к дальнейшему этапу машинного обучения.*

# **Разведочный анализ данных**

# *Для начало загрузим представленную выборку и стандартные библиотеки машинного обучения:*

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import nltk 
import re
from nltk.stem import wordnet 
from sklearn.feature_extraction.text import CountVectorizer 
from sklearn.feature_extraction.text import TfidfVectorizer 
from nltk import pos_tag 
from sklearn.metrics import pairwise_distances, classification_report 
from nltk import word_tokenize 
from nltk.tokenize import sent_tokenize, word_tokenize
import nltk
import re
from nltk.corpus import stopwords
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC
from sklearn.externals import joblib
from tkinter import*
from tkinter import filedialog as fd
from sklearn.svm import SVC


# In[2]:


data=pd.read_csv('billdoard_dataset.csv')
data.head(5)


# *Теперь необходимо посмотреть размер выборки и различные статистические меры, также не лишним будет посмотреть тип каждого атрибута:*

# In[3]:


data.shape


# *Выборка не очень большого размера, она имеет 6 признаков и 3879 объектов.*

# In[4]:


data.describe()


# *Можно увидеть, что статистическая мера нормальная в данных, так как дисперсия не большая.*

# In[5]:


data.dtypes


# **Обработка попущенных значений**

# *Сушествует три метода обработки пропущенных значений*
# ***
# * *Удаление атрибутов или пропущенных значений(следует применять, если выборка большого размера, а значений отсутствует мало.)*
# * *Замена пропущенных значений в количественных признаках на среднее или мелианное значение, в категориальных на моду или новую категорию.(лучше всего работает, если значения отсутсвуют случайно.)*
# * *Прогнозирование(Используется только тогда, когда значения пропустили намеренно, а также признаки имею взаимосвязь между заменяемымим значениями.)*
# ***
# *Для того, что-бы определить, какой способ нам подойдет, необходимо вывести количество пропущенных значений на экран:*

# In[6]:


data.isnull().sum()


# *Как видно, в данных нету пропущенных значений.*

# **Разделение сложных атрибутов**

# *Сложный атрибут в данных пристствует только один, это дата, которую нужно разделить на год, месяц и день:*

# In[7]:


def inger(input_str):
    first=input_str.partition(' ')[0]
    return first


# In[8]:


def inger_mean(input_str):
    mean=input_str.partition(' ')[2]
    return mean


# In[9]:


data['Day']=data['start_date'].apply(inger)


# In[10]:


data['Month_year']=data['start_date'].apply(inger_mean)


# In[11]:


data['Year']=data['Month_year'].apply(inger_mean)


# In[12]:


data['Month']=data['Month_year'].apply(inger)


# In[13]:


del data['Month_year']
del data['start_date']


# In[14]:


data


# **Формирование словаря**

# *Для завершения предобработки предстоит создать новый признак в выборке-словарь.*
# ***
# *Для начла приведем все номинативные признаки в нижний регистр:*

# In[15]:


data['description']=data['description'].str.lower()


# *В нашем словаре должны присутствовать слова из признака description , причем слова не должны повторятся, для этого можно воспользоваться векторизацией, которая будет выводить только ключевые слова из признака, а также токенизацией, что-бы разделить все предложения:*

# In[21]:


def text_normalization(text):
    text=str(text).lower() 
    spl_char_text=re.sub(r'[^ а-я]','',text) 
    tokens=nltk.word_tokenize(spl_char_text) 
    lema=wordnet.WordNetLemmatizer()
    tags_list=pos_tag(tokens,tagset=None) 
    lema_words=[]    
    for token,pos_token in tags_list:
        if pos_token.startswith('V'):  
            pos_val='v'
        elif pos_token.startswith('J'): 
            pos_val='a'
        elif pos_token.startswith('R'):
            pos_val='r'
        else:
            pos_val='n'
        lema_token=lema.lemmatize(token,pos_val)
        lema_words.append(lema_token) 
    
    return " ".join(lema_words) 


# In[22]:


text=text_normalization(data['description'])


# In[23]:


tfidf=TfidfVectorizer()
x_tfidf=tfidf.fit_transform(data['description'])


# In[24]:


df=pd.DataFrame(x_tfidf)


# In[25]:


data= pd.concat([df,data],axis=1)


# In[26]:


data.rename(columns={0:'Dictionary'}, inplace=True)


# In[27]:


data


# *Теперь закодируем номинативные признаки, без этого действия мы не сможем обучить наши данные.*

# In[28]:


lbl=LabelEncoder()
nomic_df=data.select_dtypes(exclude=[np.number])
df_cols_nomic=nomic_df.columns.values
for col in df_cols_nomic:
    data[col]=lbl.fit_transform(data[col].astype('str'))


# # Сессия_2

# *В этой сессии необходимо проанализировать данные, и оставить только такие признаки для обучения, которые хорошо зависят от целевой переменной.Также заранее требуется определиться с алгоритмами  обучения*

# *Для того, что-бы посмотреть зависимость признаков от целевого атрибута,  выведем на экран диграмму попарной зависимости:*

# In[29]:


sns.pairplot(data, hue='Year', palette='Greys_r');


# *По диограмме видно, что атрибуты хорошо зависят от целевого признака, потому-что все они расположены на плоскости хаотично, некоторые признаки даже образуют на плоскости линию, чтоговорит о их сильной корреляции с целевым признаком.* 

# In[30]:


data.hist(color='darkblue', figsize=(14,12));


# *Видно, что распределены признаки ассимитрично, но если учитывать , что в данных больше номинативных признаков, тогда можно сказать, что распределение не плохое, так как количество наблюдений практически везде разное.*

# In[31]:


plt.figure(figsize=(8, 12))
heatmap=sns.heatmap(data.corr()[['Year']].sort_values(by='Year', ascending=False), vmin=-1, vmax=1, cmap='Greens_r',
                    fmt='.1f', annot=True);


# *Коэффициент корреляции признаки имею хороший от целевого атрибута, так как он меньше 0.4, это говорит о том, что обычные атрибуты не имеют схожести с целевым признаком.*

# *Также необходимо выбрать алгоритмы, которые будут использоваться для обучения.
# **В качестве классификатора** возьмем: k-ближайших соседей-так как он лучше всего работает с большим количеством категорий и имеет всего два параметра, также используем для обучения ансамблевый алгоритм XGBoost, он очень хорошо предсказызывает за счет того, что состоит из двух и более простых алгоритмов, а также воспользуемся алгоритмом Методом опорных векторов.

# # Сессия_3

# *В этой сессии необходимо приступить к обучению модели, с помощью алгоритмов которые были выбраны в предыдущей сессии.*
# ***
# *Для начало нужно нормализовать выборку, для того, что-бы значения распологались в одном диапазоне, это позволит увеличить вероятность прогноза.*

# In[32]:


scaler=MinMaxScaler()
df_scaler=scaler.fit_transform(data.drop('Year', axis=1))
pd.DataFrame(df_scaler, columns=(data.drop('Year',axis=1).columns))


# *Что бы приступить к обучению, необходимо разделить выборку на тестовую и тренировочную части,что-бы при поступлении новых объектов модель могла корректно переобучаться.*

# In[33]:


x=df_scaler.copy()
y=data['Year']


# In[34]:


x_train, x_test, y_train, y_test=train_test_split(x,y, test_size=0.33, random_state=20,stratify=y)


# *Обучение с помощью алгоритма k-ближайших соседей:*

# In[35]:


kneg=KNeighborsClassifier(n_neighbors=6)


# In[36]:


kneg.fit(x_train, y_train)


# In[37]:


y_pred=kneg.predict(x_test)


# In[38]:


kneg.score(x_test, y_test)


# *Реализация алгоритма Метод опорных векторов:*

# In[40]:


tear=SVC(random_state=19, C=2)


# In[41]:


tear.fit(x_train, y_train)


# In[42]:


y_pred=tear.predict(x_test)


# In[43]:


print(classification_report(y_test, y_pred))


# In[44]:


tear.score(x_test ,y_test)


# *Применение ансамблевого алгоритма XGBoost:*

# In[45]:


xgb=XGBClassifier(random_state=110,n_estmats=22, learning_rate=0.19,min_child_weight=1,gamma=0,subsample=0.9,colsample_bytree=0.8,nthread=4,scale_pos_weight=1,seed=27)


# In[46]:


xgb.fit(x_train, y_train)


# In[47]:


y_pred=xgb.predict(x_test)


# In[48]:


xgb.score(x_test, y_test)


# # Сессия_4

# *В заключений обучения, для того, что-бы пользователю было удобно пользоваться обученной моделью, необходимо создать программный продукт на основе прошлого обучения.*

# *Для начало сохраним нашу модель:*

# In[53]:


joblib.dump(tear,"tear_clf.pkl")


# *Теперь необходимо создать функцию, в которой будет содержаться предобработка и сохраненная модель:*

# In[59]:


def praprocess_data(file):
    data = pd.read_csv(file)
    def inger(input_str):
        first=input_str.partition(' ')[0]
        return first
    def inger_mean(input_str):
        mean=input_str.partition(' ')[2]
        return mean
    data['Day']=data['start_date'].apply(inger)
    data['Month_year']=data['start_date'].apply(inger_mean)
    data['Year']=data['Month_year'].apply(inger_mean)
    data['Month']=data['Month_year'].apply(inger)
    del data['Month_year']
    del data['start_date']
    def text_normalization(text):
        text=str(text).lower() 
        spl_char_text=re.sub(r'[^ а-я]','',text) 
        tokens=nltk.word_tokenize(spl_char_text) 
        lema=wordnet.WordNetLemmatizer()
        tags_list=pos_tag(tokens,tagset=None) 
        lema_words=[]    
        for token,pos_token in tags_list:
            if pos_token.startswith('V'):  
                pos_val='v'
            elif pos_token.startswith('J'): 
                pos_val='a'
            elif pos_token.startswith('R'):
                pos_val='r'
            else:
                pos_val='n'
            lema_token=lema.lemmatize(token,pos_val)
            lema_words.append(lema_token) 
        return " ".join(lema_words) 
    text=text_normalization(data['description'])
    tfidf=TfidfVectorizer()
    x_tfidf=tfidf.fit_transform(data['description'])
    df=pd.DataFrame(x_tfidf)
    data= pd.concat([df,data],axis=1)
    data.rename(columns={0:'Dictionary'}, inplace=True)
    lbl=LabelEncoder()
    nomic_df=data.select_dtypes(exclude=[np.number])
    df_cols_nomic=nomic_df.columns.values
    for col in df_cols_nomic:
        data[col]=lbl.fit_transform(data[col].astype('str'))
    scaler=MinMaxScaler()
    df_scaler=scaler.fit_transform(data.drop('Year', axis=1))
    df_new=pd.DataFrame(df_scaler, columns=(data.drop('Year',axis=1).columns))
    return df_new
    
def predict(df_new):
    clf=joblib.load('tear_clf.pkl')
    y_pred=clf.predict(df_new)
    return y_pred


# In[60]:


dataset=praprocess_data('billdoard_dataset.csv')


# In[61]:


predict(dataset)


# In[83]:


root=Tk()
root.minsize(325,200)
def insertText():
    file_name=fd.askopenfilename(title="Выберите файлы")
    df_new=praprocess_data(file_name)
    y_pred=predict(df_new)
    text.insert(1.0,pd.Series(y_pred))
text=Text(width=50, height=25,)
text.grid(columnspan=2)
button=Button(text="Нажмите, чтобы \n получить предсказание", command=insertText).grid(columnspan=2)
root.mainloop()


# In[ ]:




