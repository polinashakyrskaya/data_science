#!/usr/bin/env python
# coding: utf-8

# # Сессия_1

# *В этой сессии необходимо загрузить и предобработать представленную выборку.Для этого пoтребуется выполнить следующие пункты:*
# ***
# * *Парсинг данных*
# * *Обработка попущенных значений*
# * *Разделение сложных атрибутов*
# * *Кодирование номинативных признаков*
# * *Формирование структуры набора данных*
# ***
# *После этой сессии выборка будет обработана, что позволит перейти к дальнейшему этапу машинного обучения.*

# **Парсинг данных**

# *Для начало загрузим представленную выборку и стандартные библиотеки машинного обучения:*

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')
from sklearn.model_selection import train_test_split
from nltk.stem import wordnet 
from sklearn.feature_extraction.text import CountVectorizer 
from sklearn.feature_extraction.text import TfidfVectorizer 
from nltk import pos_tag 
from sklearn.metrics import pairwise_distances, classification_report, accuracy_score
from nltk import word_tokenize 
from nltk.tokenize import sent_tokenize, word_tokenize
import nltk
import re
from nltk.corpus import stopwords
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC
from tkinter import*
from tkinter import filedialog as fd
from sklearn.svm import SVC


# In[2]:


df_1=pd.read_csv('install_info.csv')
df_2=pd.read_csv('register_info.csv')
df_3=pd.read_excel('phone-data.xlsx')


# *После загрузки необходимо соединить одинаковые признаки всех датафреймов:*

# In[3]:


data_1=np.concatenate([df_1['安装时间'], df_2['安装时间'], df_3['安装时间']],axis=0)
data_2=np.concatenate([df_1['用户唯一ID'], df_2['用户唯一ID'], df_3['用户唯一ID']], axis=0)
data_3=np.concatenate([df_1['WIFI'], df_3['WIFI']], axis=0)
data_4=np.concatenate([df_1['地区'], df_2['地区'], df_3['地区']], axis=0)
data_5=np.concatenate([df_1['子渠道'], df_2['子站'], df_3['子渠道']],axis=0)
data_6=np.concatenate([df_1['渠道'], df_3['渠道']],axis=0)
data_7=np.concatenate([df_1['操作系统版本'], df_3['操作系统版本']],axis=0)
data_8=np.concatenate([df_1['系统'], df_2['系统'], df_3['系统']], axis=0)
data_9=np.concatenate([df_1['机型'], df_2['机型'], df_3['机型']],axis=0)
data_10=df_2['用户类型']
data_11=df_2['账号名称']
data_12=df_2['注册时间']
data_13=df_2['注册渠道']
data_14=df_2['注册游戏']


# In[4]:


data_1=pd.DataFrame(data_1)
data_2=pd.DataFrame(data_2)
data_3=pd.DataFrame(data_3)
data_4=pd.DataFrame(data_4)
data_5=pd.DataFrame(data_5)
data_6=pd.DataFrame(data_6)
data_7=pd.DataFrame(data_7)
data_8=pd.DataFrame(data_8)
data_9=pd.DataFrame(data_9)
data_10=pd.DataFrame(data_10)
data_11=pd.DataFrame(data_11)
data_12=pd.DataFrame(data_12)
data_13=pd.DataFrame(data_13)
data_14=pd.DataFrame(data_14)


# *Переименуем наши признаки, так как все заголовки нааны на китайском.*

# In[5]:


data_1['Время установки']=data_1
data_2['Индефикатр']=data_2
data_3['WIFI']=data_3
data_4['Регионы']=data_4
data_5['Подстанция']=data_5
data_6['Каналы']=data_6
data_7['Версия Оп']=data_7
data_8['Система']=data_8
data_9['Модель']=data_9
data_10['用户类型']
data_11['账号名称']
data_12['注册时间']
data_13['注册渠道']
data_14['注册游戏']


# In[6]:


data_10.rename(columns={'用户类型':'Тип пользователя'}, inplace=True)
data_11.rename(columns={'账号名称':'Индификатор'}, inplace=True)
data_12.rename(columns={'注册时间':'Время регистрации'}, inplace=True)
data_13.rename(columns={'注册渠道':'Зарегистрируйтесь в канале'}, inplace=True)
data_14.rename(columns={'注册游戏':'Зарегистрируйтесь для участия в игре'}, inplace=True)


# *Теперь соеденим все выборки в одну, что-бы в дальнейшем с ней было легче работать:*

# In[7]:


data= pd.concat([data_1, data_2, data_3, data_4, data_5, data_6, data_7, data_8, data_9, data_10, data_11, data_12, data_13, data_14], axis=1)


# In[8]:


del data[0]


# In[9]:


data.head(4)


# **Разделение сложных атрибутов**

# *В представленной выборке присуствуют такие признаки, где находяться несколько значений.К таким признакам относиться дата, разделим ее на день, месяц, год, и время:*

# In[10]:


data['Регионы'] = data['Регионы'].map(str.strip)
data['Система'] = data['Система'].map(str.strip)
data['Модель'] = data['Модель'].map(str.strip)


# In[11]:


data['Время установки']=pd.to_datetime(data['Время установки'])


# In[12]:


data.head(3)


# In[13]:


data['День установки']= pd.DatetimeIndex(data['Время установки']).weekday
data['Месяц установки']= pd.DatetimeIndex(data['Время установки']).month
data['Год установки']= pd.DatetimeIndex(data['Время установки']).year


# In[14]:


data['Время установки']= pd.DatetimeIndex(data['Время установки']).time


# In[15]:


data


# **Обработка попущенных значений**

# *Теперь необходимо обработать пропущенные значения в данных.Существует три метода:*
# * *Удаление призаков или значений(применять лучше если пропущенных значений отсутствует мало ,а выборка имеет большой размер)*
# * *Замена пропщенных значений на моду числа или среднее или мелианное значение(считается самым стандартным способом)*
# * *Предсказание пропщенных значений(здесь важно, что бы призанки имели зависимость от признаков с пропущенными значениями)*

# *Что бы определить каким способом мы будем обрабатывать пропущенные значения, посмотрим на их колличество:*

# In[16]:


plt.figure(figsize=(10,8))
data.isnull().sum().plot(kind='barh', color='lightgreen');


# *Так как пропущенных значений мало, и большиноство из них не случайно отсутствуют мы воспользуемся методом-заменой заменой пропущенных значений.Все категориальные признаки я заменю модой числа, а количественные-мелианным значением:*

# In[17]:


df_nomeric=data.select_dtypes(include=[np.number])
non_cols=df_nomeric.columns.values
for col in non_cols:
    missing=data[col].isnull()
    non_missing=np.sum(missing)
    if non_missing>0:
        print('inputing missing for:{}'.format(col))
        med=data[col].median()
        data[col]=data[col].fillna(med)


# In[18]:


df_nomeric=data.select_dtypes(exclude=[np.number])
non_cols=df_nomeric.columns.values
for col in non_cols:
    missing=data[col].isnull()
    non_missing=np.sum(missing)
    if non_missing>0:
        print('inputing missing for:{}'.format(col))
        top=data[col].describe()['top']
        data[col]=data[col].fillna(top)


# **Кодирование номинативных признаков**

# *Переведем номинативные признаки в числа:*

# In[19]:


lbl=LabelEncoder()
nomic_df=data.select_dtypes(exclude=[np.number])
df_cols_nomic=nomic_df.columns.values
for col in df_cols_nomic:
    data[col]=lbl.fit_transform(data[col].astype('str'))


# **Формирование структуры набора данных**

# *Отбор признаков – это важная задача для любого приложения с машинным обучением. Особенно важно, когда данные, о которых идет речь, имеют много признаков. Выделить наиболее важные признаки и найти количество оптимальных можно с помощью определения важности признаков или их ранжирования, в качестве оценщика будет GradientBoostingClassifier, для начала, загрузим все необходимые библиотеки:*

# In[20]:


from sklearn.pipeline import Pipeline
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.model_selection import cross_val_score
from sklearn.feature_selection import RFE
import numpy as np
from lightgbm import LGBMClassifier
from sklearn.feature_selection import RFECV


# *Также необходимо разделить данные:*

# In[21]:


X = data.drop('Тип пользователя',axis=1)
y = data['Тип пользователя']
X_train, X_test, y_train, y_test = train_test_split(X, y,random_state=10)


# In[22]:


data.shape


# In[23]:


rfe = RFE(estimator=LGBMClassifier(), n_features_to_select=7)


# In[24]:


model = LGBMClassifier()


# In[25]:


pipe = Pipeline([("Feature Selection", rfe), ("Model", model)])
cv = RepeatedStratifiedKFold(n_repeats=5, random_state=36851234, n_splits=2)
n_scores = cross_val_score(pipe, X_train, y_train, scoring="accuracy", cv=cv, n_jobs=-1)
np.mean(n_scores)


# In[26]:


pipe.fit(X_train, y_train)


# *Ранжирование признака:*

# In[27]:


pd.DataFrame(rfe.support_,index=X.columns,columns=["Тип пользователя"])


# In[28]:


rf_df = pd.DataFrame(rfe.ranking_,index=X.columns,columns=["Тип пользователя"]).sort_values(by="Тип пользователя",ascending=True)


# In[29]:


rf_df.head()


# *Из выше выведенных таблиц, можно сделать вывод, что все признаки важны для целевой переменной, и некоторые признак плохо зависит от целевой переменнной, удалим их:*

# **Везуализация**

# *В этом модуле необходимо будет обучить признаки на выбранном классификаторе, для этого нужно будет выполнить следующие пункты :*
# 
# * *Отбор признаков*
# * *Разбиение данных*
# * *Обучение модели на классификаторе*
# 
# *При выполнении этих пунктов, у нас будет обученные признаки на классификаторе.*

# *Для начало нужно отобрать только хорошо зависимые от целевых переменных признаки, и с хорошим распределением, для этого нужно построить гистограмму распределения и диаграмму попарной зависимости:*  

# In[30]:


sns.pairplot(data[['Версия Оп', 'День установки', 'Месяц установки', 'Год установки', 'WIFI']], palette='YlOrBr', hue='WIFI');


# *На диограмме распределения видно, что признаки предикторы хорошо зависят от целевых атрибутов, так как не имеют схожести с ними, а также все значения признаков расположены по всей плоскости, что тже свидетельствует о нормальной зависимости.*

# In[31]:


data.hist(color='lightblue', figsize=(8,8));


# *Из гистограммы распределеня можно сделать вывод, что признаки расположены семетрично, это значит, что здесь нету признаков, которые нужно было бы удалить.*

# *Теперь посмотрим на коэффициент кореляции между двумя целевыми и предикторными признаками:*

# In[32]:


plt.figure(figsize=(8, 12))
heatmap = sns.heatmap(data.corr()[['Тип пользователя']].sort_values(by='Тип пользователя', ascending=False), vmin=-1, vmax=1, annot=True, cmap='Greys',fmt=".1f")
heatmap.set_title('Features Correlating with Sales Price', fontdict={'fontsize':18}, pad=16);


# **Классификация**

# *Теперь разделим наши данные на тестувую и тренировочную части, что бы при поступлении новых данных наша модель давала правельные результаты,разделять данные можно многими способами, но я воспользуюсь самым стандартным train_test_split, так как его легче и удобнее всего применять при классификации:*

# In[33]:


scaler=StandardScaler()
df_scaler=scaler.fit_transform(data.drop('Тип пользователя', axis=1))
pd.DataFrame(df_scaler, columns=(data.drop('Тип пользователя',axis=1).columns))


# *Что бы приступить к обучению, необходимо разделить выборку на тестовую и тренировочную части,что-бы при поступлении новых объектов модель могла корректно переобучаться.*

# In[34]:


x=df_scaler.copy()
y=data['Тип пользователя']


# In[35]:


x_train, x_test, y_train, y_test=train_test_split(x,y, test_size=0.33, random_state=20,stratify=y)


# *Обучение с помощью алгоритма k-ближайших соседей:*

# In[36]:


kneg=KNeighborsClassifier(n_neighbors=6)


# In[37]:


kneg.fit(x_train, y_train)


# In[38]:


y_pred=kneg.predict(x_test)


# In[39]:


kneg.score(x_test, y_test)


# *Реализация алгоритма Метод опорных векторов:*

# In[40]:


tear=SVC(random_state=19, C=2)


# In[41]:


tear.fit(x_train, y_train)


# In[42]:


y_pred=tear.predict(x_test)


# In[43]:


print(classification_report(y_test, y_pred))


# In[44]:


data['Тип пользователя'].value_counts()


# In[45]:


tear.score(x_test ,y_test)


# *Применение ансамблевого алгоритма XGBoost:*

# In[46]:


xgb=XGBClassifier(random_state=110,n_estmats=22, learning_rate=0.19,min_child_weight=1,gamma=0,subsample=0.9,colsample_bytree=0.8,nthread=4,scale_pos_weight=1,seed=27)


# In[47]:


xgb.fit(x_train, y_train)


# In[48]:


y_pred=xgb.predict(x_test)


# In[49]:


xgb.score(x_test, y_test)


# **Чат-бот**

# In[50]:


data=data.astype('int')


# In[51]:


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from tkinter import *
from nltk import word_tokenize 
from nltk.corpus import stopwords 
import nltk 
import re
from nltk.stem import wordnet 
from sklearn.feature_extraction.text import CountVectorizer 
from sklearn.feature_extraction.text import TfidfVectorizer 
from nltk import pos_tag 
from sklearn.metrics import pairwise_distances 
from nltk import word_tokenize 
from nltk.corpus import stopwords 
import string
import bs4 as bs
import numpy as np
import urllib.request
import warnings
warnings.filterwarnings("ignore")


# In[52]:


raw_html = urllib.request.urlopen('https://ru.wikipedia.org/wiki/%D0%A1%D0%BE%D1%82%D0%BE%D0%B2%D1%8B%D0%B9_%D1%82%D0%B5%D0%BB%D0%B5%D1%84%D0%BE%D0%BD')
raw_html = raw_html.read()
article_html = bs.BeautifulSoup(raw_html, 'lxml')
article_paragraphs = article_html.find_all('p')
article_text = ''
for para in article_paragraphs:
    article_text += para.text
article_text = article_text.lower()


# In[53]:


article_text = re.sub(r'\[[0-9]*\]', ' ', article_text)
article_text = re.sub(r'\s+', ' ', article_text)


# In[54]:


article_sentences = nltk.sent_tokenize(article_text)
article_words = nltk.word_tokenize(article_text)


# In[55]:


wnlemmatizer = nltk.stem.WordNetLemmatizer()
def perform_lemmatization(tokens):
    return [wnlemmatizer.lemmatize(token) for token in tokens]

punctuation_removal = dict((ord(punctuation), None) for punctuation in string.punctuation)
def get_processed_text(document):
    return perform_lemmatization(nltk.word_tokenize(document.lower().translate(punctuation_removal)))


# In[56]:


def generate_response(user_input):
    tennisrobo_response = ''
    article_sentences.append(user_input)

    word_vectorizer = TfidfVectorizer(tokenizer=get_processed_text, stop_words='english')
    all_word_vectors = word_vectorizer.fit_transform(article_sentences)
    similar_vector_values = cosine_similarity(all_word_vectors[-1], all_word_vectors)
    similar_sentence_number = similar_vector_values.argsort()[0][-2]

    matched_vector = similar_vector_values.flatten()
    matched_vector.sort()
    vector_matched = matched_vector[-2]
    tennisrobo_response = tennisrobo_response + article_sentences[similar_sentence_number]
    return tennisrobo_response


# In[57]:


continue_dialogue = True
print("Bot: Введите команду /comand, что-бы посмотреть,\nкакие команды я умею выполнять.")
while(continue_dialogue == True):
    human_text = input()
    human_text = human_text.lower()
    if human_text != '/end':
        if human_text == '/comand':
            print("Bot: Я умею выполнять следующие команды: \n/comand, /predict, /text, /end.")
        elif human_text == '/predict':
            pred=input('Введите порядковый номер мобильного телефона:')
            pred=y_pred[int(pred)]
            if pred == 0:
                strin='Молодым'
            else:
                strin='Старшему поколкению'
            print('Bot: Пользователи которые чаще выберают эту модель относятся к :{}'.format(strin))
        elif human_text == '/text':
            intent=input('Введите вопрос:')
            print("Bot:" + generate_response(intent))
            
        else:
            print('Bot: Такие команды я не умею выполнять, введите /comand,что-бы посмотреть,\nкакие команды я умею выполнять.')
    else:
        continue_dialogue = False
        print("Bot: Пока")


# **GUI**

# In[58]:


import tkinter


# In[98]:


root=Tk()
root.title('API')
root.geometry('400x600')
def com():
    input_get = ent.get()
    print(input_get)
    pred=y_pred[int(input_get)]
    if pred==0:
        r=c.create_oval(10, 10, 60, 60,fill="red")
    else:
        g=c.create_oval(10, 130, 60, 180,fill="green")
btn=Button(root, text='Спрогнозировать', command=com)
btn.place(x=250, y=120)
ent=Entry(root, width=10)
ent.place(x=250, y=100)
root.title("Светофор")
c = Canvas(root, width=70, height=190,bg="grey")
r=c.create_oval(10, 10, 60, 60,fill="white")
g=c.create_oval(10, 130, 60, 180,fill="white")
c.place(x=10, y=10)
root.mainloop()


# In[ ]:




